import './App.css';

import PersonDefaultDemo from './Components/DefaultProp'

//import ArrayProps from './Components/ArrayAsProps'


// import ParentSampleRenderProps from './Components/RenderPropDemo'

//import GrandParent from './Components/Live';

function App() {
  return (
    // Default Prop - Class Componet with Props
    <div >
      <PersonDefaultDemo></PersonDefaultDemo>
      <PersonDefaultDemo name="Dhruv Joshi" gender="Male"></PersonDefaultDemo>
      <PersonDefaultDemo name="Ekta Vyas" gender="Female"></PersonDefaultDemo>
      <PersonDefaultDemo name="Vimir Joshi" gender="Male"></PersonDefaultDemo>
    </div>
   // Array as Props
    //<ArrayProps></ArrayProp

    // Render Props
    // <ParentSampleRenderProps/>
    
  );
}

export default App;
