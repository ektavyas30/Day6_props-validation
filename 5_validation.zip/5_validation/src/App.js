import './App.css';
import ValidationDemo from './Component/ValidationDemo';

function App() {
  return (
    // <UseStateFun/>
    // <SetStateCLS/>
    <ValidationDemo/>
  );
}

export default App;
